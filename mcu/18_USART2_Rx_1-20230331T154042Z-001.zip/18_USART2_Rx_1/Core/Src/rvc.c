/*
 * rvc.c
 *
 *  Created on: Nov 24, 2022
 *      Author: PHY202209EF13
 */


#include "main.h"

UART_HandleTypeDef USART2_Handler;


//User Data
char *USER_DATA= "Hello Gopal!\r\n";

uint8_t Rcvd_Data;
uint8_t Data_Buffer[100];


int main()
{
	HAL_Init();

	SystemClockConfig();

	USART2_Init();

	HAL_UART_Transmit(&USART2_Handler, (uint8_t*)USER_DATA, strlen(USER_DATA), HAL_MAX_DELAY);

	uint32_t count = 0;

	while(1)
	{
		HAL_UART_Receive(&USART2_Handler, &Rcvd_Data, 1, HAL_MAX_DELAY);    //Read byte by byte

		if(Rcvd_Data == '\r')
		{
			//detect Return/Enter key
			Data_Buffer[count++] = '\r';
			break;
		}
		else
		{
			Data_Buffer[count++] = Convert_To_Upper(Rcvd_Data);
		}
	}

	HAL_UART_Transmit(&USART2_Handler, (uint8_t*)Data_Buffer, count, HAL_MAX_DELAY);

	while(1);

	return 0;
}
