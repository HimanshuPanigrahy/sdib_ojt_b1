/*
 * USART2_Rx_REG.c
 *
 *  Created on: Nov 24, 2022
 *      Author: PHY202209EF13
 */

#include "main.h"

unsigned char uart_read()
{
	while(!(USART2->SR & 0x20)){}
	return USART2->DR;
}

void USART2_Tx(unsigned char data)
{
	while(!(USART2->SR & 0x80))
	{

	}
	USART2->DR |= (data & 0xFF);
}

void USART2_Send(unsigned char *str)
{
	while(*str)
	{
		USART2_Tx(*str);
		delay(500);
		str++;
	}
}


void delay(int T)
{
	while(T--)
	{
		for(int i=0;i<5000;i++);
	}
}


void Sconfig_Init()
{
	RCC->APB1ENR |= 0X20000;
	RCC->AHB1ENR |= 0x1;     //ENABLE PORT A IN APB1ENR REGISTER
	GPIOA->MODER |= 0xA0;    //ACTIVATING PA2 AND PA3 AS ALTERNATING MODE
	GPIOA->AFR[0]|= 0X7700;   //PA2 AS USART2_TX AND PA3 AS USART2_RX
	USART2->BRR  |= 0X683;   //BAUD RATE 9600 SELECTION
	USART2->CR1  |= 0X2000;  //ENABLE UE OF USART2_CR1
	USART2->CR1  |= 0XC;  //ENABLE RE AND TE OF USART2_CR1
}

void led_init()
{
	GPIOA->MODER |= 0x400;
}

int led_toggle(char data[])
{
	if(data[0] == 'L' && data[1] == 'O' && data[2] == 'N')
	{
				GPIOA->BSRR |=0x20;
//				delay(1000);
//				GPIOA->BSRR |=0x200000;
//				delay(1000);

	}
	if(data[0] == 'L' && data[1] == 'O' && data[2] == 'F')
	{

//					GPIOA->BSRR |=0x20;
//					delay(1000);
					GPIOA->BSRR |=0x200000;
//					delay(1000);
	}
	return 0;
}

char dat[3];
char bit;
int count1=0;
int main()
{
	Sconfig_Init();
	led_init();
	while(1)
	{

		bit = uart_read();
		delay(10);
		if(bit == '\r')
		{
			break;
		}
		else
		{
			dat[count1++] = bit;
		}
		USART2_Send(dat);
		led_toggle(dat);
	}
}







