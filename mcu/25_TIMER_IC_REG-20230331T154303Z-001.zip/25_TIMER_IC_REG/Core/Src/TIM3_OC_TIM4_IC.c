/*
 * TIM3_OC_TIM4_IC.c
 *
 *  Created on: Dec 3, 2022
 *      Author: PHY202209EF13
 */


#include"stm32f4xx.h"
#include"main.h"
int timeStamp = 0;

int main(void)
{
	// Compare PA7 as output mode TIM3_CH2
	RCC->AHB1ENR |= 1;                             // Enable GPIO clock
	GPIOA->MODER &=~0x0000C000;                    // Clear pin mode
	GPIOA->MODER |= (1<<15);                       // Set the pin to alternate pin
	GPIOA->AFR[0] &=~(0xF<<28);                    // Set pin to AF0 bits
	GPIOA->AFR[0] |= (2<<28);                      // Set pin to AF0 for TIM3 CH2

	// Configure TIM3 to wrap around at 1 Hz
	// and toggle CH2 output when the counter value is 0

	RCC->APB1ENR |= 2;                             // Enable TIM3 clock
	TIM3->PSC = 1600 -1;                           // Divided by 1600
	TIM3->ARR = 10000 - 1;                         // Divided by 10,000
	TIM3->CCMR1 = (3<<12);                            // Set output toggle on match
	TIM3->CCR2 = 0;                                 // Set match value
	TIM3->CCER |= (1<<4);                               // Enable ch2 compare mode
	TIM3->CNT = 0;                                 // clear counter
	TIM3->CR1 = 1;                                 // Enable TIM3;

//	configure PB8 as input of TIM4 CH3

	RCC->AHB1ENR |= 2;                             // Enable GPIOA clock
	GPIOB->MODER &=~0x30000;                        // CLear Pin mode
	GPIOB->MODER |= (2<<16);                        // Set pin to alternate function
	GPIOB->AFR[1]&= ~(0xF);                    // clear pin AF bits
	GPIOB->AFR[1]|=0x2;                      // Set pin to AF2 for TIM4 CH3

//	Configure TIM4 to do input capture with present with prescalar ...as 16MHz/16000 given

	RCC->APB1ENR |= 4;                             // Enable TIM4 clock
	TIM4->PSC = 16000 - 1;                         // divided by 16000
	TIM4->CCMR2 = 0x41;                            // set CH3 to capture at every...
	TIM4->CCER = (1<<8);                                // enable CH 3 capture rising
	TIM4->CR1 = 1;                                 // Enable TIM4
	while(1)
	{
		while(!(TIM4->SR & 8)){}                  // wait until input edge is capture
		timeStamp = TIM4->CCR3;                   // read capture counter value
	}
}
