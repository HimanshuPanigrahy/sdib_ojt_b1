/*
 * TIMER_OC.c
 *
 *  Created on: Dec 1, 2022
 *      Author: PHY202209EF13
 */



#include "main.h"

int main()
{
	RCC->AHB1ENR |= 1;
	GPIOA->MODER &= ~0xC00;
	GPIOA->MODER |= 0x800;
	GPIOA->AFR[0]|= 0x100000;

	//CONFIGURE TIM2 TO WRAP AROUND AT 50HZ
	RCC->APB1ENR |= 1;
	TIM2->PSC = 1600-1;
	TIM2->ARR = 10000-1;
	TIM2->CCMR1 = 0x30;   //SET OUTPUT TO TOGGLE ON MATCH MODE
	TIM2->CCR1 = 0;      //SET MATCH VALUE . CH1 MODE
	TIM2->CCER |= 1;    //ENABLE CH1 COMPARE MODE
	TIM2->CNT = 0;
	TIM2->CR1 = 0x11;

	while(1){}
}
