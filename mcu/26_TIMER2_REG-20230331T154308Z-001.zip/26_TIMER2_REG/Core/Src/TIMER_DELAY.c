
#include "main.h"

int main()
{
	RCC->AHB1ENR |= 1;
	GPIOA->MODER &= ~0x30000;
	GPIOA->MODER |= 0x10000;

	//CONFIGURE TIM2 TO WRAP AROUND AT 50HZ
	RCC->APB1ENR |= 1;
	TIM2->PSC = 1600-1;
	TIM2->ARR = 2000-1;
	TIM2->CNT = 0;
	TIM2->CR1 = 0x11;

	while(1)
	{
		while(!(TIM2->SR & 1)){}
		TIM2->SR &= ~1;
		GPIOA->ODR ^= 0x100;
	}
}
