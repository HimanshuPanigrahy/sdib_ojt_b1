#include "main.h"

//TIM_HandleTypeDef htim10;

//
//static void timer_delay(void)
//{
//
//  /* USER CODE BEGIN TIM10_Init 0 */
//
//  /* USER CODE END TIM10_Init 0 */
//
//  /* USER CODE BEGIN TIM10_Init 1 */
//
//  /* USER CODE END TIM10_Init 1 */
//  htim10.Instance = TIM10;
//  htim10.Init.Prescaler = 15999;
//  htim10.Init.CounterMode = TIM_COUNTERMODE_UP;
//  htim10.Init.Period = 10000;
//  htim10.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
//  htim10.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
//  if (HAL_TIM_Base_Init(&htim10) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN TIM10_Init 2 */
//
//  /* USER CODE END TIM10_Init 2 */
//
//}

void timer_init()
{
	RCC->APB2ENR |= 0x20000;
	GPIOB->MODER |= 0X20000;
	GPIOB->AFR[1]|= 0x3;
}



void timer_delay()
{

	TIM10->PSC |= 15999-1;
	TIM10->ARR |=1000;
	TIM10->CNT |=0X0;
	TIM10->CR1 |=0X1;
}



int main()
{
	//ENABLE GPIO
	RCC->AHB1ENR |= 0X3;
	GPIOA->MODER |= 0X400;
	timer_init();


	while(1)
	{
		timer_delay();
		while(!(TIM10->SR & 1));

		GPIOA->ODR ^=0x20;
		TIM10->SR |=0;
	}
}
