/*
 * USART2_REG.c
 *
 *  Created on: Nov 23, 2022
 *      Author: PHY202209EF13
 *
 *      STEP 1:- PROTOCOL SELECTED USART2
 *      STEP 2:- ENABLE APB1 CLOCK WITH RCC
 *      STEP 3:- ENABLE AHB1 BUS WITH RCC
 *      STEP 4:- ALTERNATIVE FUNCTION OF PA2 AS USART2_TX
 *      STEP 5:- ALTERNATIVE FUNCTION OF PA3 AS USART2_RX
 *
 *
 */

#include "main.h"

void delay(int T)
{
	while(T--)
	{
		for(int i=0;i<5000;i++);
	}
}
void Sconfig_Init()
{
	RCC->APB1ENR |= 0X20000;
	RCC->AHB1ENR |= 0x1;     //ENABLE PORT A IN APB1ENR REGISTER
	GPIOA->MODER |= 0x20;    //ACTIVATING PA2 AS ALTERNATING MODE
	GPIOA->AFR[0]|= 0X700;   //PA2 AS USART2_TX
	USART2->BRR  |= 0X683;   //BAUD RATE 9600 SELECTION
	USART2->CR1  |= 0X2000;  //ENABLE UE OF USART2_CR1
	USART2->CR1  |= 0X0008;  //ENABLE TE OF USART2_CR1
}


void USART2_Tx(unsigned char data)
{
	while(!(USART2->SR & 0x80))
	{

	}
	USART2->DR |= (data & 0xFF);
}

void USART2_Send(unsigned char *str)
{
	while(*str)
	{
		USART2_Tx(*str);
		delay(500);
		str++;
	}
}


//char Data[10] = "Hello\r\n";
int main()
{

	Sconfig_Init();
	while(1)
	{
		USART2_Send("Hello\n\r");
		//delay(500);
	}



}
